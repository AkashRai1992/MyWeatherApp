package Constants;

/**
 * Created by akki on 20/4/15.
 */
public interface NetworkConst {
    String REQ_METHOD_GET = "GET";

    String TAG_REST = " REST ";
}
