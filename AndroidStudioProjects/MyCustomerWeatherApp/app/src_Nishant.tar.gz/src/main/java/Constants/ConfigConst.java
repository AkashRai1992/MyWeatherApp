package Constants;

/**
 * Created by akki on 20/4/15.
 */
public interface ConfigConst {
    String URL_CURRENT_WEATHER = "http://api.openweathermap.org/data/2.5/weather";
    String URL_FUTURE_WEATHER ="http://api.openweathermap.org/data/2.5/forecast/daily";
    String URL_CURRENT_WEATHER_ICON="http://openweathermap.org/img/w/";
     String URL_FUTURE_WEATHER_FORMAT="http://api.openweathermap.org/data/2.5/forecast";
}
