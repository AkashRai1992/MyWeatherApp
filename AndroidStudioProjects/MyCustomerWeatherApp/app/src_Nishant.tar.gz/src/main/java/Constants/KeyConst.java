package Constants;

/**
 * Created by akki on 20/4/15.
 */
public interface KeyConst {
    String KEY_DATA = "KEY_DATA";
}
